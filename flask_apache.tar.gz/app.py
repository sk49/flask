from flask import Flask,request
#from flask_cors import CORS, cross_origin
import api_data
import json
from prediction import make_prediction

app = Flask(__name__)
#CORS(app)

@app.route('/companies')
def retrieveListOfCompanys():
    
     results = api_data.GetCompanyList()
     print results
     return results.to_json(orient='index')

@app.route('/version')
def getApiVersion():
    version = {'I.D':'V2.0.0'}
    return (json.dumps(version))

@app.route('/engine',methods=['POST'])
def riskProbability():
    
    request.get_json(force=True)
     
    if request.method =='POST':
        invoice = request.json

        supplier_id = invoice["Supplier"]
        client_id = invoice["Buyer"]
        amount = invoice["Amount"]
        invoice_date = invoice["InvoiceDate"]
        due_date = invoice["InvoiceDueDate"]         
                            
    risk_probabilities = make_prediction(client_id, supplier_id, amount, invoice_date, due_date)
      
    if risk_probabilities is None:
        
           return "Invoice parties not in database"
    else:
         return json.dumps(risk_probabilities) 

if __name__ == '__main__':

        app.run(host='0.0.0.0', port=5000, debug=True)
                   

