import urllib2
 
url1 = 'https://ec2-user@ec2-54-241-136-139.us-west-1.compute.amazonaws.com:5000/version'

response1 = urllib2.urlopen(url1).read()
print "1 ",response1

url2 = 'https://ec2-user@ec2-54-241-136-139.us-west-1.compute.amazonaws.com:5000/companies'

response2 = urllib2.urlopen(url2).read()
print "2 ", response2
url3 = 'https://ec2-user@ec2-54-241-136-139.us-west-1.compute.amazonaws.com:5000/engine'

event = {

 "Supplier": "A0000001",
  "Buyer": "A195005",
  "Amount": 1234,
  "InvoiceDate": "2017-01-12",
  "InvoiceDueDate": "2017-01-18"
}

data = urllib.urlencode(values)
request = urllib2.Request(url,data)
response3 = urllib2.urlopen(request).read()
print "3 ", response3
