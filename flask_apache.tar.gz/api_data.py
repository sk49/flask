
# coding: utf-8

# ## Originally Python Notebook
# Convert this to api_data.py


# In[20]:

import MySQLdb 
import pandas as pd
import numpy as np

# MySQL Server Connections
#serverHost = 'staging-flowdb.czp741euxfsc.us-west-1.rds.amazonaws.com'
serverHost = 'prod-flowdb.czp741euxfsc.us-west-1.rds.amazonaws.com'
serverPort = 3306
dbUser = 'fcast_prod'
dbPass = 'fcast_prod'
dbName = 'samurai'

### List_of_companies

def GetCompanyList():
        table1 = 'raw_client_paid_invoices'
        table2 = 'raw_client_company'

	'''
	get list of company ids and names 
	'''	
	conn = MySQLdb.connect(host=serverHost,   # your host, usually localhost
						user=dbUser,       # your username
						passwd=dbPass,     # your password
						db=dbName)

	query = '''
	SELECT DISTINCT '''+table1+'''.client_id,name
	''' + "FROM " + table1 + '''
	INNER JOIN '''+ table2 +''' ON '''+table1+'''.client_id = '''+table2+'''.client_id
	
	ORDER BY name DESC
	'''
	
	df = pd.read_sql(query, conn)
	
	conn.close()
	
	return df


