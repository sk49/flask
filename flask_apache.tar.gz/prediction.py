import pandas as pd
import numpy as np
import pickle
from datetime import datetime

right_order=[u'invoice_amount', u'Pmt_terms', u'TimeBetweenInvoices',
       u'PriorInvoicesPaid', u'AmtPriorInvoicesPaid', u'PriorInvoicesPaidLate',
       u'AmtPriorInvoicesPaidLate', u'PriorLateCountRatio',
       u'PriorLateAmtRatio', u'OutstandingInvoices', u'OutstandingAmt',
       u'LateOutstandingInvoices', u'LateOutstandingAmt',
       u'OutstandingLateCountRatio', u'OutstandingLateAmtRatio']

def make_prediction(client_id,supplier_id,amount,invoice_date,due_date):
    lookuptable=pd.read_csv("LookupTable.csv")
    column_names=lookuptable.columns.values
    feature_values=lookuptable.loc[(lookuptable['client_id']==client_id) & (lookuptable['supplier_id']==supplier_id)]
    
    if len(feature_values)==0:
        return None
    
    invoice_year=int(invoice_date.split("-")[0])
    invoice_month=int(invoice_date.split("-")[1])
    invoice_day=int(invoice_date.split("-")[2])
    
    due_year=int(due_date.split("-")[0])
    due_month=int(due_date.split("-")[1])
    due_date=int(due_date.split("-")[2])
    
    payment_term=(pd.Timestamp(datetime(due_year, due_month, due_date))-pd.Timestamp(datetime(invoice_year, invoice_month, invoice_day))).days
    feature_values['Pmt_terms']=payment_term
    feature_values['invoice_amount']=amount
    feature_values=feature_values[right_order]
    
    model=pickle.load( open( "my_dumped_classifier.pkl", "rb" ) )
    probabilites=model.predict_proba(feature_values.loc[0].values)
    print (probabilites)
    
    return {"0-5 days":probabilites[0][0],"5-60 days":probabilites[0][1],"over 60 days":probabilites[0][2]}
